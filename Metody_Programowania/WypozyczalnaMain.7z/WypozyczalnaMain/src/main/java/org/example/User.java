package org.example;

public class User {
    //tylko id
    private int id;

    public User(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
