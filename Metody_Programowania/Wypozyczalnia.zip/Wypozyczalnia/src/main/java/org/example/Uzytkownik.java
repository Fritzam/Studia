package org.example;

public class Uzytkownik {
    //tylko id

    int IDUzytkownika = 1614023412;

    Uzytkownik(int IDUzytkownika) {
        this.IDUzytkownika = IDUzytkownika;
    }
}
