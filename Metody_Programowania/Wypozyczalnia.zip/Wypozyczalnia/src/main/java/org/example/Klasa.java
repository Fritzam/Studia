package org.example;

public enum Klasa {
    premium,
    standard,
    economical
}
